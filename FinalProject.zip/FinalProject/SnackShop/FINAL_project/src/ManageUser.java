import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import com.mysql.jdbc.Driver;

public class ManageUser extends JInternalFrame implements ActionListener,MouseListener{
 JTable user;
 JPanel panel,pickgender;
 JLabel namatable,id,nama,email,pass,role,address,dob,gender;
 JTextField inputid,inputnama,inputemail;
 JPasswordField inputpass;
 JTextArea inputaddress;
 JComboBox<Integer> day,month,year;
 JComboBox<String>roleinput;
 DefaultTableModel model;
 JButton insert,update,delete;
 JRadioButton m,f,invis;
 ButtonGroup gendergroup;
 TableColumnModel colmdl;
 int highid;
 String userdob;
 
 void gethighestid() {
		try {
			Driver.class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
			Statement stm= con.createStatement();
			ResultSet rs = stm.executeQuery("select MAX(UserId) from user");
			while(rs.next()) {
				 highid=rs.getInt(1);
			}
			stm.close();
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
			
	}
 
 void deluser() {
	 try {
			int delrow=Integer.parseInt(user.getModel().getValueAt(user.getSelectedRow(),0).toString());
			Driver.class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
			PreparedStatement pstmt = con.prepareStatement("delete from user where UserID =?");
			pstmt.setInt(1, delrow);
			pstmt.execute();
			model.setRowCount(0);
			selectuser();
			pstmt.close();
			con.close();
		}catch(Exception e2){
			e2.getMessage();
		}
 }
 
 void upduser() {
	 try {
			Driver.class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
			PreparedStatement pstmt = con.prepareStatement("update user set Roleid = ?,UserName = ?,UserGender=?,UserDOB=?,Useraddress=?,UserEmail=?,UserPassword=? where UserID = ?");
			if(roleinput.getSelectedItem()=="User") {
				pstmt.setInt(1, 1);
				}else if(roleinput.getSelectedItem()=="Admin") {
					pstmt.setInt(1, 2);
				}
			pstmt.setString(2, inputnama.getText());
			if(f.isSelected()) {
				pstmt.setString(3, f.getText() );	
			}else {
				pstmt.setString(3, m.getText());
			}
			pstmt.setString(4, userdob);
			pstmt.setString(5, inputaddress.getText());
			pstmt.setString(6,inputemail.getText());
			pstmt.setString(7, inputpass.getText());
			pstmt.setInt(8, Integer.parseInt(inputid.getText()));
			pstmt.executeUpdate();
			model.setRowCount(0);
			selectuser();
			pstmt.close();
			con.close();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.getMessage();
		}	
 }
 
 void insuser() {
	 gethighestid();
			try {
				Driver.class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
				PreparedStatement pstmt = con.prepareStatement("insert into user values(?,?,?,?,?,?,?,?)");
				pstmt.setInt(1,(highid+1));
				if(roleinput.getSelectedItem()=="User") {
				pstmt.setInt(2, 1);
				}else if(roleinput.getSelectedItem()=="Admin") {
					pstmt.setInt(2, 2);
				}
				pstmt.setString(3, inputnama.getText());
				if(f.isSelected()) {
					pstmt.setString(4, f.getText() );	
				}else {
					pstmt.setString(4, m.getText());
				}
				pstmt.setString(5, userdob);
				pstmt.setString(6, inputaddress.getText());
				pstmt.setString(7,inputemail.getText());
				pstmt.setString(8, inputpass.getText());
				pstmt.executeUpdate();
				model.setRowCount(0);
				selectuser();
				pstmt.close();
				con.close();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.getMessage();
			}	
		}
 
 void selectuser() {
	 try {
			Driver.class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from user");
			while(rs.next()) {
				model.addRow(new Object[] {rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4),rs.getDate(5),rs.getString(6),rs.getString(7),rs.getString(8)});
			}
			stmt.close();
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
 }
 
 void init() {
	 panel = new JPanel(new GridBagLayout());
	 pickgender= new JPanel(new GridLayout(1,2));
	 gendergroup = new ButtonGroup();
	 roleinput= new JComboBox<String>();
	 roleinput.addItem("-");
	 roleinput.addItem("Admin");
	 roleinput.addItem("User");
	 m= new JRadioButton("Male");
	 f = new JRadioButton("Female");
	 invis= new JRadioButton();
	 insert= new JButton("Insert");
	 update= new JButton("Update");
	 delete= new JButton("Delete");
	 insert.setPreferredSize(new Dimension(130,30));
	 update.setPreferredSize(new Dimension(130,30));
	 delete.setPreferredSize(new Dimension(130,30));
		model = new DefaultTableModel();
		user=new JTable(model);
		user.getTableHeader().setReorderingAllowed(false);
		colmdl = user.getColumnModel();
		namatable= new  JLabel("Users");
		id= new  JLabel("ID");
		nama = new  JLabel("Nama");
		email = new  JLabel("Email");
		pass = new  JLabel("Password");
		role = new  JLabel("Role");
		address = new  JLabel("Address");
		dob = new  JLabel("Date Of Birth");
		gender = new  JLabel("Gender");
		inputid= new JTextField(20);
		inputnama= new JTextField(20);
		inputemail= new JTextField(20);
		inputpass = new JPasswordField(20);
		inputaddress = new JTextArea(2,20);
		inputaddress.setLineWrap(true);
		inputaddress.setWrapStyleWord(true);
		day= new JComboBox<Integer>();
		month = new JComboBox<Integer>();
		year = new JComboBox<Integer>();
		for(int i=1;i<=31;i++){
			day.addItem(i);
		}
		for(int i=1;i<=12;i++){
			month.addItem(i);
		}
		for(int i=1975;i<=2021;i++){
			year.addItem(i);
		}
		model.addColumn("UserID");
		model.addColumn("RoleID");
		model.addColumn("UserName");
		model.addColumn("UserGender");
		model.addColumn("UserDOB");
		model.addColumn("UserAddress");
		model.addColumn("UserEmail");
		model.addColumn("UserPassword");
		user.setPreferredScrollableViewportSize(new Dimension(600,400));
		gendergroup.add(f);
		gendergroup.add(m);
		gendergroup.add(invis);
		pickgender.add(f);
		pickgender.add(m);
		selectuser();
		GridBagConstraints cons= new GridBagConstraints();
		cons.insets= new Insets(0,0,-50,20);
		cons.gridy=0;
		panel.add(namatable,cons);
		cons.gridy=3;
		cons.insets= new Insets(-20,-20,0,0);
		panel.add(new JScrollPane(user),cons);
		cons.insets= new Insets(20,0,0,0);
		cons.gridx=3;
		cons.gridy=1;
		panel.add(id,cons);
		cons.insets= new Insets(20,0,0,0);
		cons.gridx=4;
		cons.gridy=1;
		panel.add(inputid,cons);
		cons.insets= new Insets(20,0,0,0);
		cons.gridx=3;
		cons.gridy=2;
		panel.add(nama,cons);
		cons.gridx=4;
		cons.gridy=2;
		panel.add(inputnama,cons);
		cons.insets= new Insets(-120,0,220,0);
		cons.gridx=3;
		cons.gridy=3;
		panel.add(email,cons);
		cons.gridx=4;
		cons.gridy=3;
		panel.add(inputemail,cons);
		cons.insets= new Insets(-620,0,20,0);
		cons.gridx=3;
		cons.gridy=4;
		panel.add(pass,cons);
		cons.gridx=4;
		cons.gridy=4;
		panel.add(inputpass,cons);
		cons.insets= new Insets(-520,0,20,0);
		cons.gridx=3;
		cons.gridy=5;
		panel.add(role,cons);
		cons.gridx=4;
		cons.gridy=5;
		panel.add(roleinput,cons);
		cons.insets= new Insets(-420,0,20,0);
		cons.gridx=3;
		cons.gridy=6;
		panel.add(address,cons);
		cons.gridx=4;
		cons.gridy=6;
		panel.add(inputaddress,cons);
		cons.insets= new Insets(-320,0,20,0);
		cons.gridx=3;
		cons.gridy=7;
		panel.add(dob,cons);
		cons.insets= new Insets(-320,-160,20,0);
		cons.gridx=4;
		cons.gridy=7;
		panel.add(day,cons);
		cons.insets= new Insets(-320,-40,20,0);
		cons.gridx=4;
		cons.gridy=7;
		panel.add(month,cons);
		cons.insets= new Insets(-320,80,20,0);
		cons.gridx=4;
		cons.gridy=7;
		panel.add(year,cons);
		cons.insets= new Insets(-220,0,20,0);
		cons.gridx=3;
		cons.gridy=8;
		panel.add(gender,cons);
		cons.gridx=4;
		cons.gridy=8;
		panel.add(pickgender,cons);
		cons.insets= new Insets(-120,0,20,0);
		cons.gridx=4;
		cons.gridy=9;
		panel.add(insert,cons);
		cons.insets= new Insets(-40,0,20,0);
		cons.gridx=4;
		cons.gridy=10;
		panel.add(update,cons);
		cons.insets= new Insets(0,0,20,0);
		cons.gridx=4;
		cons.gridy=11;
		panel.add(delete,cons);
		add(panel,BorderLayout.NORTH);
 }
 
 
	public ManageUser() {
		super("Manage User",false,true,false);
		setSize(1100,600);
		setVisible(true);
		init();
		insert.addActionListener(this);
		update.addActionListener(this);
		delete.addActionListener(this);
		user.addMouseListener(this);
	}

	
	public static void main(String[] args) {
		new ManageUser();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==insert) {
			int count=0;
			boolean checkat=false;
			for(int i=0;i<inputemail.getText().length();i++) {
				if(inputemail.getText().charAt(i)=='@') {
					count++;
					if(count>1) {
						checkat=true;
						count=0;
					}
				}else if(count==1||count!=0) {
					checkat=false;
					
				}
				
			}	
			boolean checkmail=false;
			for(int i=0;i<inputemail.getText().length();i++) {
				if(inputemail.getText().charAt(i)=='@') {
					try {
						if(inputemail.getText().charAt(i+1)=='.') {
							checkmail=true;
						}else {
							checkmail=false;
						}
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.getMessage();
					}
				}
			}
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		 userdob=year.getSelectedItem()+"-"+month.getSelectedItem()+"-"+day.getSelectedItem();
		LocalDate now = LocalDate.now();
			if(inputnama.getText().length()<5||inputnama.getText().length()>30) {
				JOptionPane.showMessageDialog(null,"Name must be between 5-30 characters","Error",JOptionPane.ERROR_MESSAGE);
			}else if(checkmail==true||checkat==true||inputemail.getText().startsWith("@")||inputemail.getText().startsWith(".")||!inputemail.getText().endsWith(".com")) {
				JOptionPane.showMessageDialog(null, "Invalid Email Format","Error",JOptionPane.ERROR_MESSAGE);
			}else if(inputpass.getText().length()<5||inputpass.getText().length()>30) {
				JOptionPane.showMessageDialog(null, "Password must be between 5-20 characters","Error",JOptionPane.ERROR_MESSAGE);
			}else if(roleinput.getSelectedItem()=="-") {	
				JOptionPane.showMessageDialog(null, "Choose role","Error",JOptionPane.ERROR_MESSAGE);
			}else if(!inputaddress.getText().endsWith("Street")) {
				JOptionPane.showMessageDialog(null, "Address must be ends with �Street�","Error",JOptionPane.ERROR_MESSAGE);
			}else if(userdob.compareTo(now.toString())>0) {
				JOptionPane.showMessageDialog(null, "Date of Birth must be at least day before today","Error",JOptionPane.ERROR_MESSAGE);
			}else if(!(f.isSelected()||m.isSelected())){
				JOptionPane.showMessageDialog(null, "Gender must be checked","Error",JOptionPane.ERROR_MESSAGE);
			}else {
				insuser();
				JOptionPane.showMessageDialog(null, "Insert Sucess","Sucess",JOptionPane.INFORMATION_MESSAGE);
				inputemail.setText("");
				inputnama.setText("");
				inputpass.setText("");
				inputaddress.setText("");
				roleinput.setSelectedItem("-");
				day.setSelectedItem(1);
				month.setSelectedItem(1);
				year.setSelectedItem(1975);
				invis.setSelected(true);
			}	
		}else if(e.getSource()==update) {
			int count=0;
			boolean checkat=false;
			for(int i=0;i<inputemail.getText().length();i++) {
				if(inputemail.getText().charAt(i)=='@') {
					count++;
					if(count>1) {
						checkat=true;
						count=0;
					}
				}else if(count==1||count!=0) {
					checkat=false;
					
				}
				
			}	
			boolean checkmail=false;
			for(int i=0;i<inputemail.getText().length();i++) {
				if(inputemail.getText().charAt(i)=='@') {
					try {
						if(inputemail.getText().charAt(i+1)=='.') {
							checkmail=true;
						}else {
							checkmail=false;
						}
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.getMessage();
					}
				}
			}
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		 userdob=year.getSelectedItem()+"-"+month.getSelectedItem()+"-"+day.getSelectedItem();
		LocalDate now = LocalDate.now();
		if((user.getSelectedRow()<0)) {
			JOptionPane.showMessageDialog(null, "Choose user","Error",JOptionPane.ERROR_MESSAGE);
		}else if(inputnama.getText().length()<5||inputnama.getText().length()>30) {
				JOptionPane.showMessageDialog(null,"Name must be between 5-30 characters","Error",JOptionPane.ERROR_MESSAGE);
			}else if(checkmail==true||checkat==true||inputemail.getText().startsWith("@")||inputemail.getText().startsWith(".")||!inputemail.getText().endsWith(".com")) {
				JOptionPane.showMessageDialog(null, "Invalid Email Format","Error",JOptionPane.ERROR_MESSAGE);
			}else if(inputpass.getText().length()<5||inputpass.getText().length()>30) {
				JOptionPane.showMessageDialog(null, "Password must be between 5-20 characters","Error",JOptionPane.ERROR_MESSAGE);
			}else if(roleinput.getSelectedItem()=="-") {	
				JOptionPane.showMessageDialog(null, "Choose role","Error",JOptionPane.ERROR_MESSAGE);
			}else if(!inputaddress.getText().endsWith("Street")) {
				JOptionPane.showMessageDialog(null, "Address must be ends with �Street�","Error",JOptionPane.ERROR_MESSAGE);
			}else if(userdob.compareTo(now.toString())>0) {
				JOptionPane.showMessageDialog(null, "Date of Birth must be at least day before today","Error",JOptionPane.ERROR_MESSAGE);
			}else if(!(f.isSelected()||m.isSelected())){
				JOptionPane.showMessageDialog(null, "Gender must be checked","Error",JOptionPane.ERROR_MESSAGE);
			}else {
				upduser();
				JOptionPane.showMessageDialog(null, "update Sucess","Success",JOptionPane.INFORMATION_MESSAGE);
				inputemail.setText("");
				inputnama.setText("");
				inputpass.setText("");
				inputaddress.setText("");
				roleinput.setSelectedItem("-");
				day.setSelectedItem(1);
				month.setSelectedItem(1);
				year.setSelectedItem(1975);
				invis.setSelected(true);
			}
				
		}else if(e.getSource()==delete) {
			if((user.getSelectedRow()<0)) {
				JOptionPane.showMessageDialog(null, "Choose user","Error",JOptionPane.ERROR_MESSAGE);
			}else {
				deluser();
				JOptionPane.showMessageDialog(null, "delete Sucess","Success",JOptionPane.INFORMATION_MESSAGE);
			}
		}
		
	}


	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource()==user) {
			inputid.setText(model.getValueAt(user.getSelectedRow(), 0).toString());
		}
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.mysql.jdbc.Driver;

public class TransactionHistory extends JInternalFrame implements MouseListener {

	JTable detailtrans,trans;
	DefaultTableModel model1, model2;
	JPanel Header,Body;
	JLabel detailtran,tran;
	int getranid;
	
	void hdtrans(){
		try {
			Driver.class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
			Statement stmt1 = con.createStatement();
			
			ResultSet rs1 = stmt1.executeQuery("select headertransaction.TransactionId,SUM(snack.snackPrice * detailtransaction.Quantity),TransactionDate from headertransaction inner join detailtransaction on headertransaction.TransactionId=detailtransaction.TransactionId inner join snack on detailtransaction.snackId=snack.snackId where userid ='"+Login.id+"' group by detailtransaction.TransactionId"); 
			
			while(rs1.next()) {
				int IDtrans= rs1.getInt(1);
				int ttl= rs1.getInt(2);
				Date date= rs1.getDate(3);
				model1.addRow(new Object[] {IDtrans,ttl,date});
			}
			con.close();
			stmt1.close();
			rs1.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
	}
	
	void tbldtltrans() {
		try {
		Driver.class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
		Statement stmt2= con.createStatement();
		ResultSet rs2 = stmt2.executeQuery("select snack.snackName,snack.snackPrice,Quantity from detailtransaction inner join snack on detailtransaction.snackid=snack.snackid where detailtransaction.transactionid="+getranid);
		while(rs2.next()) {
			String snackname= rs2.getString(1);
			int price= rs2.getInt(2);
			int quantity= rs2.getInt(3);
			model2.addRow(new Object[] {snackname,price,quantity});
		}
		con.close();
		stmt2.close();
		rs2.close();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.getMessage();
	}
	}
	
	public void init() {
	Header = new JPanel(new GridBagLayout());
	Body= new JPanel(new GridBagLayout());
	model1 = new DefaultTableModel();
	model2 = new DefaultTableModel();
	detailtran= new JLabel("Detail Transaction");
	tran= new JLabel("Transaction");
	trans = new JTable(model1);
	detailtrans = new JTable(model2);
	Login lgn= new Login();
	
	trans.getTableHeader().setReorderingAllowed(false);
	detailtrans.getTableHeader().setReorderingAllowed(false);
	model1.addColumn("TransactionID");
	model1.addColumn("TotalPrice");
	model1.addColumn("TransactionDate");
	model2.addColumn("snackName");
	model2.addColumn("snackPrice");
	model2.addColumn("Quantity");
	GridBagConstraints cons= new GridBagConstraints();
	cons.insets=new Insets(0, 180, 0, 180);
	Header.add(tran,cons);
	Header.add(detailtran,cons);
	cons.insets=new Insets(-250, 20, 0, 20);
	Body.add(new JScrollPane(trans),cons);
	Body.add(new JScrollPane(detailtrans),cons);
	add(Body,BorderLayout.CENTER);
	add(Header,BorderLayout.NORTH);
	hdtrans();
	}
	
	public TransactionHistory() {
		super("Transaction",false,true,false);
		setVisible(true);
		setSize(1200,800);
		init();
		trans.addMouseListener(this);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource()==trans) {
			model2.setRowCount(0);
			getranid=Integer.parseInt(model1.getValueAt(trans.getSelectedRow(), 0).toString());
			tbldtltrans();
			
		}
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}

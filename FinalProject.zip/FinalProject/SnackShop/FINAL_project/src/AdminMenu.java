import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class AdminMenu extends JFrame implements ActionListener {
	
	JLabel lbl;
	JMenu User,Manage;
	JMenuBar MenuBar;
	JMenuItem Logout,Exit,ManageSnack,ManageUser;
	JDesktopPane Pane;
	JInternalFrame MenuManageSnack,MenuManageUser;

	public void init() {
		User= new JMenu("User");
		Manage= new JMenu("Manage");
		MenuBar= new JMenuBar();
		Logout= new JMenuItem("Logout");
		Exit= new JMenuItem("Exit");
		ManageSnack= new JMenuItem("Manage Snack");
		ManageUser= new JMenuItem("Manage User");
		setJMenuBar(MenuBar);
		MenuBar.add(User);
		User.add(Logout);
		User.add(Exit);
		MenuBar.add(Manage);
		Manage.add(ManageSnack);
		Manage.add(ManageUser);
		MenuBar.setBackground(Color.PINK);
		Pane= new JDesktopPane();
		add(Pane);
	}
	
	
	public AdminMenu() {
		super("Main Form");
		init();
		setVisible(true);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		ManageSnack.addActionListener(this);
		ManageUser.addActionListener(this);
		Logout.addActionListener(this);
		//background(JinternalFramenya gak muncul kalo pake background)
//				setLayout(new BorderLayout());
//				setContentPane(new JLabel(new ImageIcon("../BG/Snackshop.jpg")));
//				lbl=new JLabel();
//				add(lbl);
//				setSize(900,900);
				setSize(Toolkit.getDefaultToolkit().getScreenSize());
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==ManageSnack) {
			if(MenuManageSnack==null||MenuManageSnack.isClosed()) {
				MenuManageSnack=new ManageSnack();
				Pane.add(MenuManageSnack);
			}
		}else if(e.getSource()==ManageUser) {
			if(MenuManageUser==null||MenuManageUser.isClosed()) {
				MenuManageUser= new ManageUser();
				Pane.add(MenuManageUser);
			}
		}else if(e.getSource()==Logout) {
			main Logout= new main();
			setVisible(true);
			dispose();
		}else if(e.getSource()==Exit) {
			System.exit(0);
		}
		
	}

}

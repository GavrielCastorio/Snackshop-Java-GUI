import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.mysql.jdbc.Driver;

public class Register extends JInternalFrame implements ActionListener {
	JPanel Header,Body,Foot,inputgender,inputDOB;
	JLabel title,name,email,pass,confirmpass,adres,DOB,gender;
	JTextField inputname,inputemail;
	JPasswordField inputpass,inputconfirmpass;
	JTextArea inputadres;
	JButton Register;
	JRadioButton F,M,invis;
	ButtonGroup gendergroup;
	JComboBox<Integer> inputday,inputmonth,inputyear;
	int highid;
	String userdob,emailname;
	boolean testdup=false;
		void gethighestid() {
			try {
				Driver.class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
				Statement stm= con.createStatement();
				ResultSet rs = stm.executeQuery("select MAX(UserId) from user");
				while(rs.next()) {
					 highid=rs.getInt(1);
				}
				con.close();
				stm.close();
				rs.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.getMessage();
			}
		}
		
		void checkdata() {
			try {
				Driver.class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
				Statement stm= con.createStatement();
				ResultSet rs = stm.executeQuery("select UserEmail from user where UserEmail='"+inputemail.getText()+"'");
				if(rs.next()) {
					testdup = true;
				}
				con.close();
				stm.close();
				rs.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.getMessage();
			}
		}
		
		void insertdata() {
			try {
				gethighestid();
				Driver.class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
				PreparedStatement pstmt = con.prepareStatement("insert into user values(?,?,?,?,?,?,?,?)");
				pstmt.setInt(1,(highid+1));
				pstmt.setInt(2, 1);
				pstmt.setString(3, inputname.getText());
				if(F.isSelected()) {
					pstmt.setString(4, F.getText() );	
				}else {
					pstmt.setString(4, M.getText());
				}
				pstmt.setString(5, userdob);
				pstmt.setString(6, inputadres.getText());
				pstmt.setString(7,inputemail.getText());
				pstmt.setString(8, inputpass.getText());
				pstmt.executeUpdate();
				con.close();
				pstmt.close();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.getMessage();
			}	
		}

		public void init() {
			Header = new JPanel(new FlowLayout(FlowLayout.CENTER));
			Body= new JPanel(new GridBagLayout());
			Foot= new JPanel(new FlowLayout(FlowLayout.CENTER));
			title= new JLabel("Register Form");
			name = new JLabel("Name");
			email = new JLabel("Email : ");
			pass= new JLabel("Password : ");
			inputday= new JComboBox<Integer>();
			inputyear = new JComboBox<Integer>();
			inputmonth = new JComboBox<Integer>();
			confirmpass= new JLabel("Confirm Password : ");
			adres= new JLabel("Address : ");
			DOB = new JLabel("DateOfBirth : ");
			gender = new JLabel("Gender : ");
			F= new JRadioButton("Female");
			M= new JRadioButton("Male");
			invis= new JRadioButton();
			invis.setVisible(false);
			gendergroup= new ButtonGroup();
			gendergroup.add(F);
			gendergroup.add(M);
			gendergroup.add(invis);
			inputname = new JTextField(20);
			inputemail = new JTextField(20);
			inputpass = new JPasswordField(20);
			inputconfirmpass = new JPasswordField(20);
			inputadres= new JTextArea(2,20);
			inputadres.setLineWrap(true);
			inputadres.setWrapStyleWord(true);
			for(int i=1;i<=31;i++){
				inputday.addItem(i);
			}
			for(int i=1;i<=12;i++){
				inputmonth.addItem(i);
			}
			for(int i=1975;i<=2021;i++){
				inputyear.addItem(i);
			}
			
			
			inputgender = new JPanel(new GridLayout(1,2));
			inputgender.add(M);
			inputgender.add(F);
			Register = new JButton("Register");
			add(Header,BorderLayout.NORTH);
			add(Body,BorderLayout.CENTER);
			add(Foot,BorderLayout.SOUTH);
			Header.add(title);
			GridBagConstraints Cons = new GridBagConstraints();
			Cons.insets= new Insets(20,0,10,-10);
			Cons.gridx=0;
			Cons.gridy=0;
			Body.add(name,Cons);
			Cons.insets= new Insets(20,0,10,0);
			Cons.gridx=1;
			Cons.gridy=0;
			Body.add(inputname,Cons);
			Cons.insets= new Insets(20,0,10,-10);
			Cons.gridx=0;
			Cons.gridy=1;
			Body.add(email,Cons);
			Cons.insets= new Insets(20,0,10,0);
			Cons.gridx=1;
			Cons.gridy=1;
			Body.add(inputemail,Cons);
			Cons.insets= new Insets(20,0,10,-10);
			Cons.gridx=0;
			Cons.gridy=2;
			Body.add(pass,Cons);
			Cons.insets= new Insets(20,0,10,0);
			Cons.gridx=1;
			Cons.gridy=2;
			Body.add(inputpass,Cons);
			Cons.insets= new Insets(20,0,10,-10);
			Cons.gridx=0;
			Cons.gridy=3;
			Body.add(confirmpass,Cons);
			Cons.insets= new Insets(20,0,10,0);
			Cons.gridx=1;
			Cons.gridy=3;
			Body.add(inputconfirmpass,Cons);
			Cons.insets= new Insets(20,0,10,-10);
			Cons.gridx=0;
			Cons.gridy=4;
			Body.add(adres,Cons);
			Cons.insets= new Insets(20,0,10,0);
			Cons.gridx=1;
			Cons.gridy=4;
			Body.add(inputadres,Cons);
			Cons.insets= new Insets(20,0,10,-10);
			Cons.gridx=0;
			Cons.gridy=5;
			Body.add(DOB,Cons);
			Cons.insets= new Insets(20,-180,10,0);
			Cons.gridx=1;
			Cons.gridy=5;
			Body.add(inputday,Cons);
			Cons.insets= new Insets(20,0,10,0);
			Cons.gridx=1;
			Cons.gridy=5;
			Body.add(inputmonth,Cons);
			Cons.insets= new Insets(20,180,10,0);
			Cons.gridx=1;
			Cons.gridy=5;
			Body.add(inputyear,Cons);
			Cons.insets= new Insets(20,0,10,-10);
			Cons.gridx=0;
			Cons.gridy=6;
			Body.add(gender,Cons);
			Cons.insets= new Insets(20,0,10,0);
			Cons.gridx=1;
			Cons.gridy=6;
			Cons.weightx=1.0;
			Body.add(inputgender,Cons);
			Foot.add(Register);
		}
		
		public Register() {
			super("Register",false,true,false);
			setVisible(true);
			setSize(700,500);
			init();
			Register.addActionListener(this);
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==Register) {
				checkdata();
				System.out.println(emailname);
				System.out.println(inputemail.getText());
				int count=0;
				boolean checkat=false;
				for(int i=0;i<inputemail.getText().length();i++) {
					if(inputemail.getText().charAt(i)=='@') {
						count++;
						if(count>1) {
							checkat=true;
							count=0;
						}
					}else if(count==1||count!=0) {
						checkat=false;
						
					}
					
				}	
				
				boolean checkmail=false;
				for(int i=0;i<inputemail.getText().length();i++) {
					if(inputemail.getText().charAt(i)=='@') {
						try {
							if(inputemail.getText().charAt(i+1)=='.') {
								checkmail=true;
							}else {
								checkmail=false;
							}
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
			 userdob=inputyear.getSelectedItem()+"-"+inputmonth.getSelectedItem()+"-"+inputday.getSelectedItem();
			LocalDate now = LocalDate.now();
				if(inputname.getText().length()<5||inputname.getText().length()>30) {
					JOptionPane.showMessageDialog(null,"Name must be between 5-30 characters","Error",JOptionPane.ERROR_MESSAGE);
				}else if(checkmail==true||checkat==true||inputemail.getText().startsWith("@")||inputemail.getText().startsWith(".")||!inputemail.getText().endsWith(".com")) {
					JOptionPane.showMessageDialog(null, "Invalid Email Format","Error",JOptionPane.ERROR_MESSAGE);
				}else if(inputpass.getText().length()<5||inputpass.getText().length()>30) {
					JOptionPane.showMessageDialog(null, "Password must be between 5-20 characters","Error",JOptionPane.ERROR_MESSAGE);
				}else if(!inputconfirmpass.getText().equals(inputpass.getText())) {
					JOptionPane.showMessageDialog(null, "Confirmation Password must be the same with the Password","Error",JOptionPane.ERROR_MESSAGE);
				}else if(!inputadres.getText().endsWith("Street")) {
					JOptionPane.showMessageDialog(null, "Address must be ends with �Street�","Error",JOptionPane.ERROR_MESSAGE);
				}else if(userdob.compareTo(now.toString())>0) {
					JOptionPane.showMessageDialog(null, "Date of Birth must be at least day before today","Error",JOptionPane.ERROR_MESSAGE);
				}else if(!(F.isSelected()||M.isSelected())){
					JOptionPane.showMessageDialog(null, "Gender must be checked","Error",JOptionPane.ERROR_MESSAGE);
				}else {
					insertdata();
					emailname=inputemail.getText().substring(0,inputemail.getText().indexOf("@"));
					JOptionPane.showMessageDialog(null, "Insert Sucess "+emailname,"Sucess",JOptionPane.INFORMATION_MESSAGE);
					inputemail.setText("");
					inputname.setText("");
					inputpass.setText("");
					inputconfirmpass.setText("");
					inputadres.setText("");
					inputday.setSelectedItem(1);
					inputmonth.setSelectedItem(1);
					inputyear.setSelectedItem(1975);
					invis.setSelected(true);
					
				}
				
			}
			
		}

	

}
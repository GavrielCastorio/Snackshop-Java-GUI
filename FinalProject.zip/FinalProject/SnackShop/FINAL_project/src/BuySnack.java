

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.w3c.dom.ls.LSOutput;

import com.mysql.jdbc.Driver;

public class BuySnack extends JInternalFrame implements ActionListener,MouseListener{
	JPanel Body,header;
	JLabel Cart,Snack;
	JButton RemoveItem,Checkout,Addtocart;
	JSpinner Quantity;
	JTextField Id,Name;
	Connection Con;
	JTable tablecart,tablesnack;
	Statement st,st1;
	ResultSet rs,rs1;
	DefaultTableModel model1,model2;
	String email;
	int transid,ttlprice,qty;
	String Snackname;
	Login dtu = new Login();
	
	void hightransid() {
		try {
			Driver.class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
			Statement stm= con.createStatement();
			ResultSet rs = stm.executeQuery("select MAX(transactionid) from headertransaction");
			while(rs.next()) {
				 transid=rs.getInt(1);
			}
			model1.setRowCount(0);
			con.close();
			stm.close();
			rs.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
	}
	
	void inserttransaction() {
		hightransid();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		LocalDate now = LocalDate.now();
		transid=(transid+1);
		try {
			Driver.class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
			PreparedStatement pstm= con.prepareStatement("insert into headertransaction values(?,?,?)");
			pstm.setInt(1, (transid));
			pstm.setInt(2, Login.id);
			pstm.setString(3, now.toString());
			pstm.executeUpdate();
			con.close();
			pstm.close();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.getMessage();
		}
		
	}
	
	void insertdetailtransaction() {
		try {
			Driver.class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
			PreparedStatement pstm= con.prepareStatement("insert into detailtransaction(TransactionId,SnackId,Quantity) select "+transid+",SnackId,Quantity from cart where cart.userID ="+Login.id);
			pstm.executeUpdate();
			con.close();
			pstm.close();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.getMessage();
		}
	}
	
	void checkout() {
		inserttransaction();
		insertdetailtransaction();
		try {
			Driver.class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
			PreparedStatement pstm= con.prepareStatement("delete from cart where UserID =?");
			pstm.setInt(1, Login.id);
			pstm.executeUpdate();
			model1.setRowCount(0);
			tblcrt();
			con.close();
			pstm.close();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.getMessage();
		}
	}
	
	void removeitem(){

		try {
			String delrow=tablecart.getModel().getValueAt(tablecart.getSelectedRow(),0).toString();
			Driver.class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
			PreparedStatement pstmt = con.prepareStatement("delete from cart where SnackID =?");
			pstmt.setInt(1, Integer.parseInt(delrow));
			pstmt.execute();
			model1.setRowCount(0);
			tblcrt();
			con.close();
			pstmt.close();
		}catch(Exception e2){
			e2.getMessage();
		}
	}
	
	void updcart() {
		try {
			Driver.class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
			PreparedStatement pstm= con.prepareStatement("update cart set quantity = ? where snackid= ? and userid = ?");
			pstm.setInt(1,(qty+(int)Quantity.getValue()));
			pstm.setInt(2, Integer.parseInt(Id.getText()));
			pstm.setInt(3,Login.id );
			pstm.executeUpdate();
			model1.setRowCount(0);
			tblcrt();
			con.close();
			pstm.close();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.getMessage();
		}
	}
	
	void addtocart() {
		try {
			Driver.class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
			Statement stm= con.createStatement();
			ResultSet rs2 = stm.executeQuery("select Quantity from cart inner join snack on cart.SnackID=snack.SnackID where SnackName='"+Name.getText()+"' and UserId = "+Login.id);
			if(rs2.next()) {
				qty=rs2.getInt(1);
				updcart();
			}else {
				try {
					PreparedStatement pstm= con.prepareStatement("insert into cart values(?,?,?)");
					pstm.setInt(1, Login.id);
					pstm.setInt(2, Integer.parseInt(Id.getText()));
					pstm.setInt(3,(int) Quantity.getValue() );
					pstm.executeUpdate();
					model1.setRowCount(0);
					tblcrt();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.getMessage();
				}
			}
			con.close();
			stm.close();
			rs2.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
		
		
	}
	
	void tblsnc(){
		try {
		Driver.class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
		Statement stm= con.createStatement();
		ResultSet rs= stm.executeQuery("select SnackID,SnackName from snack");
		while(rs.next()) {
			int id = rs.getInt(1);
			String name = rs.getString(2);
			model2.addRow(new Object[] {id,name});
		}
		con.close();
		stm.close();
		rs.close();
		}catch(Exception e) {
			e.getMessage();
		}
	}
	
	void tblcrt() {
		try {
			Driver.class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
			Statement stm= con.createStatement();
			ResultSet rs2 = stm.executeQuery("select cart.SnackID,snack.SnackName,Quantity from cart inner join snack on cart.SnackID=snack.SnackID where UserId = "+Login.id);
			while(rs2.next()) {
				int idCart=rs2.getInt(1);
				String cartsnackname= rs2.getString(2);
				int SnackQuantity=rs2.getInt(3);
				model1.addRow(new Object[] {idCart,cartsnackname,SnackQuantity});
			}
			con.close();
			stm.close();
			rs2.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
	}
	
	void init() {
		Cart = new JLabel("Cart");
		Snack=new JLabel("Snack");
		Quantity=new JSpinner();
		Id= new JTextField(40);
		Name=new JTextField(40);
		Id.setEditable(false);
		Name.setEditable(false);
		Body= new JPanel(new GridBagLayout());
		header = new JPanel(new GridBagLayout());
		RemoveItem= new JButton("Remove Item");
		Checkout= new JButton("Check out");
		Addtocart= new JButton("Add to Cart");
		 RemoveItem.setPreferredSize(new Dimension(130,30));
		 Checkout.setPreferredSize(new Dimension(130,30));
		 Addtocart.setPreferredSize(new Dimension(130,30));
		model1 = new DefaultTableModel();
		model2= new DefaultTableModel();
		
		tablecart=new JTable(model1);
		tablesnack= new JTable(model2);
		int ind=tablesnack.getSelectedRow();
		tablesnack.getTableHeader().setReorderingAllowed(false);
		tablecart.getTableHeader().setReorderingAllowed(false);
		GridBagConstraints cons = new GridBagConstraints();
		add(header,BorderLayout.NORTH);
		add(Body,BorderLayout.CENTER);
		cons.insets= new Insets(0,250,0,275);
		header.add(Cart,cons);
		header.add(Snack,cons);
		model2.addColumn("SnackID");
		model2.addColumn("SnackName");
		model1.addColumn("CartID");
		model1.addColumn("SnackName");
		model1.addColumn("SnackID");
		cons.insets= new Insets(-250,25,0,55);
		Body.add(new JScrollPane(tablecart),cons);
		Body.add(new JScrollPane(tablesnack),cons);
		cons.insets= new Insets(20,-38,0,0);
		cons.gridx=0;
		cons.gridy=1;
		Body.add(RemoveItem,cons);
		cons.gridx=0;
		cons.gridy=2;
		Body.add(Checkout,cons);
		cons.insets= new Insets(20,0,0,0);
		cons.gridx=1;
		cons.gridy=1;
		Body.add(Id,cons);
		cons.gridx=1;
		cons.gridy=2;
		Body.add(Name,cons);
		cons.gridx=1;
		cons.gridy=3;
		Body.add(Quantity,cons);
		cons.gridx=1;
		cons.gridy=4;
		Body.add(Addtocart,cons);
		tblcrt();
		tblsnc();
	}	
	
	
	public BuySnack() {
		super("Buy Snack",false,true,false);
		setSize(1200,600);
		setVisible(true);
		init();
		tablesnack.addMouseListener(this);
		Addtocart.addActionListener(this);
		RemoveItem.addActionListener(this);
		Checkout.addActionListener(this);
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==Addtocart) {
			if((tablesnack.getSelectedRow()<0)) {
				JOptionPane.showMessageDialog(null, "Select A Snack","error",JOptionPane.ERROR_MESSAGE);
			}else if((int)Quantity.getValue()<1) {
				JOptionPane.showMessageDialog(null, "Quantity Must more than 0","error",JOptionPane.ERROR_MESSAGE);
			}else {
				addtocart();
			}
				
	}else if(e.getSource()==RemoveItem) {
		if((tablecart.getSelectedRow()<0)) {
			JOptionPane.showMessageDialog(null, "Select A Snack from cart","error",JOptionPane.ERROR_MESSAGE);
		}else {
			removeitem();
		}
				
	}else if(e.getSource()== Checkout) {
				checkout();
				JOptionPane.showMessageDialog(null, "All item has bought","Sucess",JOptionPane.INFORMATION_MESSAGE);
	}
		
	
	}
	@Override
	public void mouseClicked(MouseEvent e) {
	
		DefaultTableModel mdl= (DefaultTableModel)tablesnack.getModel();
		int idx=tablesnack.getSelectedRow();
		Id.setText(mdl.getValueAt(idx, 0).toString());
		Name.setText(mdl.getValueAt(idx, 1).toString());
		
	}		


	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}

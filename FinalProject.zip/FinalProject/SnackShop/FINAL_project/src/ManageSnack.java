import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Dialog.ModalExclusionType;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.regex.Pattern;

import javax.print.attribute.standard.JobKOctetsProcessed;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.mysql.jdbc.Driver;

public class ManageSnack extends JInternalFrame implements ActionListener,MouseListener{
JTable snack;
DefaultTableModel model ;
JLabel id,name,price,snacks;
JButton insert,update,delete;
JPanel panel,header;
JTextField idtf,nametf,pricetf;
int highid;
boolean cekint=true;
void gethighestsncid() {
	try {
		Driver.class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
		Statement stm= con.createStatement();
		ResultSet rs = stm.executeQuery("select MAX(SnackId) from snack");
		while(rs.next()) {
			 highid=rs.getInt(1);
		}
		con.close();
		stm.close();
		rs.close();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.getMessage();
	}
}

	void tblsnc() {
		try {
			Driver.class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
			Statement stmt = con.createStatement();
			ResultSet rs =  stmt.executeQuery("select * from snack");
			while(rs.next()) {
			model.addRow(new Object[] {rs.getString(1),rs.getString(2),rs.getInt(3)});
			}
			con.close();
			rs.close();
			stmt.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
	}
	
	void inssnc(){
		gethighestsncid();
		try {
			Driver.class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
			PreparedStatement pstmt = con.prepareStatement("insert into snack values(?,?,?)");
			pstmt.setInt(1, (highid+1));
			pstmt.setString(2, nametf.getText());
			pstmt.setInt(3, Integer.parseInt(pricetf.getText()));
			pstmt.executeUpdate();
			model.setRowCount(0);
			tblsnc();
			con.close();
			pstmt.close();
			idtf.setText("");
			nametf.setText("");
			pricetf.setText("");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.getMessage();
		}
	}

	void updsnc() {
		try {
			Driver.class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
			PreparedStatement pstmt = con.prepareStatement("update snack set SnackName =?, SnackPrice = ? where SnackId = ?");
			pstmt.setString(1,nametf.getText());
			pstmt.setInt(2,Integer.parseInt(pricetf.getText()));
			pstmt.setInt(3,Integer.parseInt(idtf.getText()));
			pstmt.executeUpdate();
			model.setRowCount(0);
			tblsnc();
			con.close();
			pstmt.close();
			idtf.setText("");
			nametf.setText("");
			pricetf.setText("");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.getMessage();
		}
	}
	
	void sncdel() {
		try {
			int delrow=Integer.parseInt(snack.getModel().getValueAt(snack.getSelectedRow(),0).toString());
			Driver.class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
			PreparedStatement pstmt = con.prepareStatement("delete from snack where SnackID =?");
			pstmt.setInt(1, delrow);
			pstmt.execute();
			model.setRowCount(0);
			tblsnc();
			con.close();
			pstmt.close();
		}catch(Exception e2){
			e2.getMessage();
		}
	}
	
	void init() {
		panel = new JPanel(new GridBagLayout());
		header= new JPanel(new GridBagLayout());
		model = new DefaultTableModel();
		snack= new JTable(model);
		snack.getTableHeader().setReorderingAllowed(false);
		idtf= new JTextField(20);
		nametf= new JTextField(20);
		pricetf= new JTextField(20);
		snacks= new JLabel("Snack");
		insert = new JButton("Insert");
		delete = new JButton("Delete");
		update = new JButton("Update");
		insert.setPreferredSize(new Dimension(200,30));
		delete.setPreferredSize(new Dimension(200,30));
		update.setPreferredSize(new Dimension(200,30));
		id= new JLabel("ID");
		name = new JLabel("Name");
		price = new JLabel("Price");
		model.addColumn("SnackId");
		model.addColumn("SnackName");
		model.addColumn("SnackPrice");
		GridBagConstraints cons= new GridBagConstraints();
		cons.insets=new Insets(-20,0,0,130);
		cons.gridy=2;
		header.add(new JScrollPane(snack),cons);
		cons.insets= new Insets(0,0,0,150);
		cons.gridy=0;
		header.add(snacks,cons);
		cons.insets= new Insets(-450,0,0,0);
		cons.gridx=3;
		cons.gridy=4;
		header.add(insert,cons);
		cons.insets= new Insets(-350,0,0,0);
		cons.gridx=3;
		cons.gridy=5;
		header.add(delete,cons);
		cons.insets= new Insets(-250,0,0,0);
		cons.gridx=3;
		cons.gridy=6;
		header.add(update,cons);
		cons.insets= new Insets(20,0,0,20);
		cons.gridx=2;
		cons.gridy=1;
		header.add(id,cons);
		cons.insets= new Insets(-320,0,0,20);
		cons.gridx=2;
		cons.gridy=2;
		header.add(name,cons);
		cons.insets= new Insets(-620,0,0,20);
		cons.gridx=2;
		cons.gridy=3;
		header.add(price,cons);
		cons.insets= new Insets(20,0,0,0);
		cons.gridx=3;
		cons.gridy=1;
		header.add(idtf,cons);
		cons.insets= new Insets(-320,0,0,0);
		cons.gridx=3;
		cons.gridy=2;
		header.add(nametf,cons);
		cons.insets= new Insets(-620,0,0,0);
		cons.gridx=3;
		cons.gridy=3;
		header.add(pricetf,cons);
		add(panel,BorderLayout.CENTER);
		add(header,BorderLayout.NORTH);
		tblsnc();
	}
	
	
	public ManageSnack() {
		super("Manage Snack",false,true,true);
		init();
		setSize(950,600);
		setVisible(true);
		insert.addActionListener(this);
		delete.addActionListener(this);
		update.addActionListener(this);
		snack.addMouseListener(this);
	}

	public static void main(String[] args) {
		new ManageSnack();
	}



	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==insert) {
	
			if(nametf.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "name empty","Error",JOptionPane.ERROR_MESSAGE);
			}else if(nametf.getText().length()<5||nametf.getText().length()>30) {
				JOptionPane.showMessageDialog(null, "name lenght must be 5-30","Error",JOptionPane.ERROR_MESSAGE);
			}else if(pricetf.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "price empty","Error",JOptionPane.ERROR_MESSAGE);
			}else {
				inssnc();
				JOptionPane.showMessageDialog(null, "Insert Sucess","Sucess",JOptionPane.INFORMATION_MESSAGE);
			}
			
		}else if(e.getSource()==update) {
			if((snack.getSelectedRow()<0)) {
				JOptionPane.showMessageDialog(null, "Choose Snack","Error",JOptionPane.ERROR_MESSAGE);
			}else if(nametf.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "name empty","Error",JOptionPane.ERROR_MESSAGE);
			}else if(nametf.getText().length()<5||nametf.getText().length()>30) {
					JOptionPane.showMessageDialog(null, "name lenght must be 5-30","Error",JOptionPane.ERROR_MESSAGE);
			}else if(pricetf.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "price empty","Error",JOptionPane.ERROR_MESSAGE);
			}else {
					updsnc();
					JOptionPane.showMessageDialog(null, "Update Sucess","Sucess",JOptionPane.INFORMATION_MESSAGE);
				}
		}else if(e.getSource()==delete) {
			if((snack.getSelectedRow()<0)) {
				JOptionPane.showMessageDialog(null, "Choose Snack","Error",JOptionPane.ERROR_MESSAGE);
			}else {
				sncdel();
				JOptionPane.showMessageDialog(null, "delete Sucess","Sucess",JOptionPane.INFORMATION_MESSAGE);
			}
		}
		
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource()==snack) {
			idtf.setText(model.getValueAt(snack.getSelectedRow(), 0).toString());
			nametf.setText(model.getValueAt(snack.getSelectedRow(), 1).toString());
			pricetf.setText(model.getValueAt(snack.getSelectedRow(), 2).toString());
		}
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

public class CustomerMenu extends JFrame implements ActionListener,MouseListener{

	JLabel lbl;
	JMenu User,BuySnack,Transaction;
	JMenuBar MenuBar;
	JMenuItem Logout,Exit ;
	JDesktopPane Pane;
	JInternalFrame TransactionMenu,BuyMenu;
	
	public void init() {
	
		MenuBar = new JMenuBar();
	BuySnack = new JMenu("BuySnack");
	Transaction = new JMenu("Transaction History");
	 User = new JMenu("User");
	Logout= new JMenuItem("Log Out");
	Exit = new JMenuItem("Exit");
	MenuBar.add(User);
	MenuBar.add(Transaction);
	MenuBar.add(BuySnack);
	User.add(Logout);
	User.add(Exit);
	setJMenuBar(MenuBar);
	MenuBar.setBackground(Color.PINK);
	Pane= new JDesktopPane();
	add(Pane);
	
	}
	public CustomerMenu() {
		super("Main Form");
		init();
		setVisible(true);
		setSize(Toolkit.getDefaultToolkit().getScreenSize());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Logout.addActionListener(this);
		BuySnack.addMouseListener(this);
		Transaction.addMouseListener(this);
		
		//background(JinternalFramenya gak muncul kalo pake background)
//				setLayout(new BorderLayout());
//				setContentPane(new JLabel(new ImageIcon("../BG/Snackshop.jpg")));
//				lbl=new JLabel();
//				add(lbl);
//				setSize(600,600);
				
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		 if(e.getSource()==Logout) {
			main logout=new main();
			setVisible(true);
			dispose();
		}else if(e.getSource()==Exit) {
			System.exit(0);
		}
		
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource()==BuySnack) {
			if(BuyMenu==null||BuyMenu.isClosed()) {
				BuyMenu=new BuySnack();
				Pane.add(BuyMenu);
			}
		}else if(e.getSource()==Transaction) {
			if(TransactionMenu==null||TransactionMenu.isClosed()) {
				TransactionMenu=new TransactionHistory();
				Pane.add(TransactionMenu);
			}
		}
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}

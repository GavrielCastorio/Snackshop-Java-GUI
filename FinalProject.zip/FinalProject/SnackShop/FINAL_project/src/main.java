import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;


public class main extends JFrame implements ActionListener{

	JButton byt;
	JMenu MainMenu;
	JMenuBar MenuBar;
	JMenuItem Login,Register,Exit;
	JDesktopPane Pane;
	JInternalFrame LoginForm,RegisterForm;
	JLabel lbl;
	JPanel pnl;

	public void init() {
	MenuBar = new JMenuBar();
	 MainMenu = new JMenu("User");
	Login= new JMenuItem("Login");
	Register=new JMenuItem("Register");
	Exit=new JMenuItem("Exit");
	MenuBar.add(MainMenu);
	MainMenu.add(Login);
	MainMenu.add(Register);
	MainMenu.add(Exit);
	setJMenuBar(MenuBar);
	MenuBar.setBackground(Color.PINK);
	Pane= new JDesktopPane();
	add(Pane);
	}
	
	
	

	public main() {
		super("Main Form");
		init();
		//BackGround(JinternalFramenya gak muncul kalo pake background)
//		setLayout(new BorderLayout());
//		setContentPane(new JLabel(new ImageIcon("../BG/Snackshop.jpg")));
//			lbl=new JLabel();
//	add(lbl);
//	setSize(600,600);
		
		
		setSize(Toolkit.getDefaultToolkit().getScreenSize());
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Login.addActionListener(this);
		Register.addActionListener(this);
		Exit.addActionListener(this);
		 
	}

	public static void main(String[] args) {
		new main();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()== Login) {
			if(LoginForm==null||LoginForm.isClosed()) {
			LoginForm = new Login();
			Pane.add(LoginForm);
			}
		}else if(e.getSource()==Register) {
				if(RegisterForm==null||RegisterForm.isClosed()) {
					RegisterForm = new Register();
					Pane.add(RegisterForm);
				}
			}else if(e.getSource()==Exit) {
				System.exit(0);
			}
		}
	
		
	}



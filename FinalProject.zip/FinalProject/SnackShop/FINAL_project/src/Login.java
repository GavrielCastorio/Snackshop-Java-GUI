import java.awt.BorderLayout;import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import com.mysql.jdbc.Driver;

public class Login extends JInternalFrame implements ActionListener {
JPanel Header,Body,Foot;
JLabel Form,Email,Password;
JTextField EmailIns;
JPasswordField PassIns;
JButton Ok;
String nama;
public static int id;

	 public void init() {
		 Form = new JLabel("Login Form");
		 Email = new JLabel("Email : ");
		 Password = new JLabel("Password : ");
		 EmailIns = new JTextField(10);
		 PassIns = new JPasswordField(10);
		 Header = new JPanel(new FlowLayout(FlowLayout.CENTER));
		 Body = new JPanel(new GridBagLayout());
		 Foot= new JPanel(new FlowLayout(FlowLayout.CENTER));
		 Ok= new JButton("Login");
		
		 
		 
		 add(Header,BorderLayout.NORTH);
		 add(Body,BorderLayout.CENTER);
		 add(Foot,BorderLayout.SOUTH);
		 
		 GridBagConstraints Cons = new GridBagConstraints();
		 Cons.insets= new Insets(10,0,20,20);
		 Cons.gridx=0;
		 Cons.gridy=0;
		 Cons.fill=GridBagConstraints.HORIZONTAL;
		 Body.add(Email,Cons);
		 Cons.fill=GridBagConstraints.HORIZONTAL;
		 Cons.gridx=1;
		 Cons.gridy=0;
		 Cons.weightx=1.0;
		 Body.add(EmailIns,Cons);
		 Cons.fill=GridBagConstraints.HORIZONTAL;
		 Cons.gridx=0;
		 Cons.gridy=1;
		 Body.add(Password,Cons);
		 Cons.fill=GridBagConstraints.HORIZONTAL;
		 Cons.gridx=1;
		 Cons.gridy=1;
		 Cons.weightx=1.0;
		 Body.add(PassIns,Cons);
		 Header.add(Form);
		 Foot.add(Ok);
	 }
	public Login()  {
		super("Login",false,true,false);
		setVisible(true);
		setSize(400,250);
		init();
		Ok.addActionListener(this);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==Ok) {
			if(EmailIns.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null,"Email Must be Filled","Error", JOptionPane.ERROR_MESSAGE);
			}else if(PassIns.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "Password Must be filled","Error", JOptionPane.ERROR_MESSAGE);
			}else {
					try {
						Driver.class.forName("com.mysql.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snack_shop","root","");
						Statement stm= con.createStatement();
						String emailuser=EmailIns.getText();
						String passuser=PassIns.getText();
						ResultSet rs = stm.executeQuery("select UserName,UserId from user where UserEmail ='"+emailuser+"' and UserPassword ='"+passuser+"'");
						if(rs.next()) {
							nama=rs.getString(1);
							id=rs.getInt(2);
							ResultSet rs2 = stm.executeQuery("select RoleID from user where UserEmail ='"+emailuser+"'");
							while(rs2.next()){
								if(rs2.getInt(1)==1) {	
									SwingUtilities.getWindowAncestor(Ok).dispose();
									CustomerMenu CM=new CustomerMenu();
									CM.setVisible(true);
									JOptionPane.showMessageDialog(null, "Welcome "+nama,"Welcome",JOptionPane.INFORMATION_MESSAGE);
								}else {
									SwingUtilities.getWindowAncestor(Ok).dispose();
									AdminMenu AM=new AdminMenu();
									AM.setVisible(true);
									JOptionPane.showMessageDialog(null, "Welcome "+nama,"Welcome",JOptionPane.INFORMATION_MESSAGE);
								}
								
							}
						}else {
							JOptionPane.showMessageDialog(null, "Invalid Email Or Password","Error",JOptionPane.ERROR_MESSAGE);
						}
						con.close();
						stm.close();
					} catch (Exception ex) {
						// TODO Auto-generated catch block
						ex.printStackTrace();
					}
					
			}
			
			
		}
		
	
	}

	

}
